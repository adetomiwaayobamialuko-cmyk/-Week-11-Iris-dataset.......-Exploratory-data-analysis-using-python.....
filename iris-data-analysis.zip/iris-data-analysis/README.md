# Iris Data Analysis

## Overview
This project performs exploratory data analysis (EDA) on the Iris dataset using Python.

## Libraries Used
- Pandas
- Matplotlib
- Seaborn

## Analysis Performed
- Dataset inspection and data types
- Missing-value checks
- Summary statistics
- Species counts
- Histograms
- Scatter plot
- Box plot
- Correlation heatmap
- Pair plot

## Setup
Install the required libraries:

```bash
python -m pip install -r requirements.txt
```

## Run
Execute the script:

```bash
python iris_analysis.py
```

Note: Seaborn may need an internet connection the first time it downloads its built-in Iris dataset.

## Dataset
The Iris dataset is loaded using Seaborn's `load_dataset("iris")` function.
