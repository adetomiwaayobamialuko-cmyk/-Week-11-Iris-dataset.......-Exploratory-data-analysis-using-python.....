import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


def main():
    # 1. Load the Iris dataset
    df = sns.load_dataset("iris")

    # 2. Inspect the dataset
    print("First five rows:")
    print(df.head())

    print("\nShape of the dataset:")
    print(df.shape)

    print("\nColumn names:")
    print(df.columns.tolist())

    print("\nData types:")
    print(df.dtypes)

    print("\nMissing values:")
    print(df.isnull().sum())

    # 3. Summary statistics
    print("\nSummary statistics:")
    print(df.describe())

    # 4. Species counts
    print("\nSpecies counts:")
    print(df["species"].value_counts())

    # 5. Histograms
    df.select_dtypes(include="number").hist(
        figsize=(10, 7),
        color="skyblue",
        edgecolor="black"
    )
    plt.suptitle("Distribution of Iris Measurements", fontsize=14)
    plt.tight_layout()
    plt.show()

    # 6. Scatter plot: Sepal Length vs Sepal Width
    plt.figure(figsize=(8, 5))
    sns.scatterplot(
        data=df,
        x="sepal_length",
        y="sepal_width",
        hue="species",
        palette="Set2",
        s=70
    )
    plt.title("Sepal Length vs Sepal Width")
    plt.xlabel("Sepal Length (cm)")
    plt.ylabel("Sepal Width (cm)")
    plt.grid(True, linestyle="--", alpha=0.5)
    plt.tight_layout()
    plt.show()

    # 7. Box plot: Petal Length by Species
    plt.figure(figsize=(8, 5))
    sns.boxplot(
        data=df,
        x="species",
        y="petal_length",
        hue="species",
        palette="Set2",
        legend=False
    )
    plt.title("Petal Length by Species")
    plt.xlabel("Species")
    plt.ylabel("Petal Length (cm)")
    plt.tight_layout()
    plt.show()

    # 8. Correlation heatmap
    numeric_df = df.select_dtypes(include="number")
    corr = numeric_df.corr()

    plt.figure(figsize=(8, 6))
    sns.heatmap(
        corr,
        annot=True,
        cmap="coolwarm",
        fmt=".2f",
        linewidths=0.5
    )
    plt.title("Correlation Matrix")
    plt.tight_layout()
    plt.show()

    # 9. Pair plot
    sns.pairplot(df, hue="species", palette="Set2")
    plt.suptitle("Pairwise Feature Relationships by Species", y=1.02)
    plt.show()


if __name__ == "__main__":
    main()
